Consumption Saving
--------------------

.. toctree::
   :maxdepth: 3

   ConsAggShockModel
   ConsGenIncProcessModel
   ConsIndShockModel
   ConsIndShockModelFast
   ConsMarkovModel
   ConsMedModel
   ConsLaborModel
   ConsPortfolioModel
   ConsPrefShochModel
   ConsRepAgentModel
   TractableBufferStockModel
