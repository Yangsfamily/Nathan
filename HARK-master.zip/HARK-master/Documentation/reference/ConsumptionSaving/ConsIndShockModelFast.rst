ConsIndShockModelFast
----------------------------

.. automodule:: HARK.ConsumptionSaving.ConsIndShockModelFast
   :members:
   :undoc-members:
   :show-inheritance:
