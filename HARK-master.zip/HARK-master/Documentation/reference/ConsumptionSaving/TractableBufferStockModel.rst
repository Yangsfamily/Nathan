TractableBufferStockModel
--------------------------

.. automodule:: HARK.ConsumptionSaving.TractableBufferStockModel
   :members:
   :undoc-members:
   :show-inheritance: