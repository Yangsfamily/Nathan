ConsLaborModel
--------------------------

.. automodule:: HARK.ConsumptionSaving.ConsLaborModel
   :members:
   :undoc-members:
   :show-inheritance: