ConsPortfolioModel
-----------------------

.. automodule:: HARK.ConsumptionSaving.ConsPortfolioModel
   :members:
   :undoc-members:
   :show-inheritance: