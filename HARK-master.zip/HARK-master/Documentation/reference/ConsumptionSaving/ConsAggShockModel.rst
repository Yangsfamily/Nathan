ConsAggShockModel
--------------------

.. automodule:: HARK.ConsumptionSaving.ConsAggShockModel
   :members:
   :undoc-members:
   :show-inheritance: