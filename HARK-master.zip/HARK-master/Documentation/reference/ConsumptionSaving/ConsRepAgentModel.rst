ConsRepAgentModel
--------------------------

.. automodule:: HARK.ConsumptionSaving.ConsRepAgentModel
   :members:
   :undoc-members:
   :show-inheritance: