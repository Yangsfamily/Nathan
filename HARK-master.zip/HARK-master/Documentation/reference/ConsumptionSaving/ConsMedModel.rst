ConsMedModel
-------------------

.. automodule:: HARK.ConsumptionSaving.ConsMedModel
   :members:
   :undoc-members:
   :show-inheritance: