ConsIndShockModel
----------------------------

.. automodule:: HARK.ConsumptionSaving.ConsIndShockModel
   :members:
   :undoc-members:
   :show-inheritance:
