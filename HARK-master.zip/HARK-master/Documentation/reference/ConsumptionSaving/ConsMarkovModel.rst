ConsMarkovModel
--------------------

.. automodule:: HARK.ConsumptionSaving.ConsMarkovModel
   :members:
   :undoc-members:
   :show-inheritance: