ConsPrefShockModel
---------------------------

.. automodule:: HARK.ConsumptionSaving.ConsPrefShockModel
   :members:
   :undoc-members:
   :show-inheritance: