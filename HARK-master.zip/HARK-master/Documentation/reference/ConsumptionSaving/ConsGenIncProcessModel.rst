ConsGenIncProcessModel
------------------------------

.. automodule:: HARK.ConsumptionSaving.ConsGenIncProcessModel
   :members:
   :undoc-members:
   :show-inheritance: