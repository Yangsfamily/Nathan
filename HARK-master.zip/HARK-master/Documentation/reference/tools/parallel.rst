Parallel
----------

.. automodule:: HARK.parallel
   :members:
   :undoc-members:
   :show-inheritance: