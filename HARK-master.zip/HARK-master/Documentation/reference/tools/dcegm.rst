dcegm
--------

.. automodule:: HARK.dcegm
   :members:
   :undoc-members:
   :show-inheritance: