Distribution
-------------

.. automodule:: HARK.distribution
   :members:
   :undoc-members:
   :show-inheritance: