Estimation
-------------

.. automodule:: HARK.estimation
   :members:
   :undoc-members:
   :show-inheritance: