Interpolation
-------------

.. automodule:: HARK.interpolation
   :members:
   :undoc-members:
   :show-inheritance: