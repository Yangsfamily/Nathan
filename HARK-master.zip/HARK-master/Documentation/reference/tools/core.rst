Core
--------

.. automodule:: HARK.core
   :members:
   :undoc-members:
   :show-inheritance: