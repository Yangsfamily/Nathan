API Documentation
==================

Tools
--------

.. toctree::
   :maxdepth: 3

   tools/index

Models
--------

.. toctree::
   :maxdepth: 3

   ConsumptionSaving/index
