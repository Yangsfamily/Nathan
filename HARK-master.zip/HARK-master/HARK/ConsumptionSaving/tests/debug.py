#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Mar  1 09:13:40 2021

@author: ccarroll
"""
import pytest
import pdb
pdb.set_trace()
pytest.main()
